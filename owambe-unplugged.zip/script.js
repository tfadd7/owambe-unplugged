document.getElementById('year').textContent = new Date().getFullYear();
document.getElementById('getTicketBtn').addEventListener('click', ()=>{
  alert('🎉 Ticket booking coming soon!');
});